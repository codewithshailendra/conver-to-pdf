package com.example.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfContentByte;

import com.itextpdf.text.pdf.PdfImage;

import com.itextpdf.text.pdf.PdfIndirectObject;

import com.itextpdf.text.pdf.PdfName;

import com.itextpdf.text.pdf.PdfReader;

import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    int STORAGE_CODE = 1000;


    EditText text;
    Button save;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (EditText) findViewById(R.id.text);
        save = (Button)findViewById(R.id.save);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Build.VERSION.SDK_INT > Build.VERSION_CODES.M){

                    if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED){
                        //ask for permission

                        String[] permission = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        requestPermissions(permission, STORAGE_CODE);
                    }else{
                        //permission granted
                        savePdf();
                    }

                }else{
                    //no need to check
                    savePdf();
                }

            }
        });

    }

    private void savePdf() {

        Document document = new Document();

        String fileName = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(System.currentTimeMillis());

        String filePath = Environment.getExternalStorageDirectory() + "/" + fileName + ".pdf";

        try{

            PdfWriter.getInstance(document, new FileOutputStream(filePath));

            document.open();

            document.setPageSize(PageSize.A4);
            document.addCreationDate();
            document.addAuthor("Steven Spielberg");
            document.addCreator("Christopher Nolan");

            BaseColor mColorAccent = new BaseColor(0, 153, 204, 255);
            float mHeadingFontSize = 20.0f;
            float mValueFontSize = 26.0f;

            BaseFont urName = BaseFont.createFont("res/font/five.otf", "UTF-8", BaseFont.EMBEDDED);

            //Line separator
            LineSeparator lineSeparator = new LineSeparator();
            lineSeparator.setLineColor(new BaseColor(0, 0, 0, 68));

            Font TitleFont = new Font(urName, 36.0f, Font.NORMAL, BaseColor.BLACK);

            Chunk TitleChunk = new Chunk("MEDICAL REPORT", TitleFont);

            Paragraph TitleParagraph = new Paragraph(TitleChunk);
            // Setting Alignment for Heading

            TitleParagraph.setAlignment(Element.ALIGN_CENTER);
            // Finally Adding that Chunk
            document.add(TitleParagraph);

            Font mOrderIdFont = new Font(urName, mHeadingFontSize, Font.NORMAL, mColorAccent);
            Chunk name = new Chunk("Jane Doe", mOrderIdFont);

            Paragraph mOrderIdParagraph = new Paragraph(name);

            document.add(new Paragraph(""));
            document.add(mOrderIdParagraph);

            document.add(new Chunk(lineSeparator));

            document.add(new Paragraph("Age: 32"));
            document.add(new Paragraph("Email: janedoe6@gmail.com"));
            document.add(new Paragraph("DOB: 5/24/1987"));

            document.add(new Chunk(lineSeparator));

            document.add(new Paragraph("Examinee: James T. Example, Jr.\n" +
                    "Claim Number: 1234\n" +
                    "Employer: abc\n" +
                    "Carrier: abc\n" +
                    "Date of Injury: February 10, 2010\n" +
                    "Requesting Client: Jane Doe\n" ));

            document.add(new Chunk(lineSeparator));

            document.add(new Paragraph("Date of Examination: March 27, 2012\n" +
                    "Examining Physician: Christopher R. Brigham, MD\n" +
                    "Specialty: Occupational Medicine, Board-Certified\n" +
                    "Examination Location: abc\n" +
                    "abc\n" +
                    "San Diego, California 92122\n" +
                    "Type of Evaluation: Independent Medical Examination"));




            document.close();

            Toast.makeText(this, "Your report has been saved in " + filePath, Toast.LENGTH_SHORT).show();

        }catch (Exception e){
            e.printStackTrace();
        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            savePdf();
        }else{
            Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
        }


    }
}
